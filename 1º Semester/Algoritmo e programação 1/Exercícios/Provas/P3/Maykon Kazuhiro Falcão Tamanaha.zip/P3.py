def separar(alunos_info):
    nome_alunos = []
    data_alunos = []
    curso_alunos = []
    i = 0
    while i < len(alunos_info):
        aluno = alunos_info[i].strip().split(",")
        nome_alunos.append(aluno[0])
        data_alunos.append(aluno[1])
        curso_alunos.append(aluno[2])
        i += 1

    return nome_alunos, data_alunos, curso_alunos

def separar_opiniao(opinioes_info):
    opinioes = []
    i = 0
    while i < len(opinioes_info):
        alunos_aqui = opinioes_info[i].strip().split(";")
        j = 0
        opinioes_do_aluno = []
        while j < len(alunos_aqui):
            opiniao = []
            aluno = alunos_aqui[j].strip().split(",")
            if aluno[0] == "[]":
                opiniao.append([])
                opiniao.append([])
            else:
                opiniao.append(aluno[0])
                opiniao.append(aluno[1])
            opinioes_do_aluno.append(opiniao)
            j += 1
        opinioes.append(opinioes_do_aluno)
        i += 1

    return opinioes

alunos = open("aluno.txt", "r")
opinioes = open("opinioes.txt", "r")

alunos_info = alunos.readlines()
nome_alunos, data_alunos, curso_alunos = separar(alunos_info)

opinioes_info = opinioes.readlines()
opinioes = separar_opiniao(opinioes_info)

def procura(busca, vetor):
    i = 0
    while i < len(vetor):
        if busca == vetor[i]:
            return i
        i += 1
    return -1

def relatorio(nome, index_aluno, opinioes_do_aluno):
    relatorio_saida = open("nomedoaluno.out", "w")

    
    sequencia_len = []
    sequencia_posicao = []
    opinioes = 0
    while opinioes < len(opinioes_do_aluno):
        opi = opinioes_do_aluno[opinioes]
        maior = len(opi[1])
        posicao = 0
        i = 0
        while i < len(opinioes_do_aluno):
            #print(sequencia_len)

            
            #print(procura(i, sequencia_posicao))
            if (procura(i, sequencia_posicao) == -1):
                opi = opinioes_do_aluno[i]

                if maior <= len(opi[1]):
                    maior = len(opi[1])
                    posicao = i


            i += 1

        sequencia_len.append(maior)
        sequencia_posicao.append(posicao)

        opinioes += 1
    
    i = 0
    while i < len(sequencia_posicao):
        vetor = opinioes_do_aluno[sequencia_posicao[i]]
        resu = str(nome) + ": " + str(vetor[0]) + ", " + str(vetor[1]) + ".\n"
        relatorio_saida.write(resu)
        i += 1

def listar_alunos(nome_alunos):
    print("Qual aluno?")
    i = 0
    while i < len(nome_alunos):
        print(str(i) + " - " + str(nome_alunos[i]))
        i += 1
    
    aluno = int(input())

    return aluno

continua = True
while continua:
    print("O que fazer?")
    print("1 - Cadastrar aluno.")
    print("2 - Cadastrar opinião.")
    print("3 - Relatório de aluno.")
    print("4 - Sair")

    escolha = int(input())

    if escolha == 1:
        print("Qual o nome do aluno?")
        nome = input()

        print("Qual a data de nascimento do aluno?")
        data = input()

        print("Qual o curso do aluno?")
        curso = input()

        nome_alunos.append(nome)
        data_alunos.append(data)
        curso_alunos.append(curso)
        opinioes.append([])
        print(opinioes)

        print("Aluno cadastrado.")

    elif escolha == 2:

        index_aluno = listar_alunos(nome_alunos)

        print("Opinião positiva ou negativa?")
        opiniao = input()

        print("Qual é a opinião?")
        opiniao_texto = input()

        opi = opinioes[index_aluno]
        if len(opi) == 0:
            opi.append(opiniao)
            opi.append(opiniao_texto)
            opinioes[index_aluno] = [opi]
        else:
            opi.append([opiniao, opiniao_texto])
            opinioes[index_aluno] = opi
        print("Opinião cadastrada.")

    elif escolha == 3:
        index_aluno = listar_alunos(nome_alunos)
        nome = nome_alunos[index_aluno]
        relatorio(nome, index_aluno, opinioes[index_aluno])


    elif escolha == 4:
        continua = False

    else:
        print("Ação inválida.")


def saida(nome_alunos, data_alunos, curso_alunos):
    resu = str(nome_alunos[0]) +"," + str(data_alunos[0]) + "," + str(curso_alunos[0]) + "\n"
    i = 1
    while i < len(nome_alunos):
        resu += str(nome_alunos[i]) +"," + str(data_alunos[i]) + "," + str(curso_alunos[i]) + "\n"
        i += 1
    return resu

def saida_opi(opinioes):
    resu = ''
    i = 0
    while i < len(opinioes):
        aluno = opinioes[i]
        if len(aluno) != 0:
            j = 0
            n_primeiro = False
            while j < len(aluno):
                if n_primeiro:
                    resu += ";" 
                n_primeiro = True
                vetor = aluno[j]
                resu += str(vetor[0]) + "," + str(vetor[1])
                j += 1
        else:
            resu += '[],[]'
        resu += "\n"
        i += 1
    
    return resu

alunos_arquivos = open("aluno.txt", "w")
opinioes_arquivos = open("opinioes.txt", "w")

alunos_arquivos.write(saida(nome_alunos, data_alunos, curso_alunos))
opinioes_arquivos.write(saida_opi(opinioes))